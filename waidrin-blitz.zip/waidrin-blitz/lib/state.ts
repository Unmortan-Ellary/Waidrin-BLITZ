// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

import { Mutex } from "async-mutex";
import { createDraft, finishDraft, type WritableDraft } from "immer";
import type * as z from "zod/v4";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";
import type { Backend } from "./backend";
import * as schemas from "./schemas";

export type View = z.infer<typeof schemas.View>;
export type World = z.infer<typeof schemas.World>;
export type Gender = z.infer<typeof schemas.Gender>;
export type Race = z.infer<typeof schemas.Race>;
export type Character = z.infer<typeof schemas.Character>;
export type LocationType = z.infer<typeof schemas.LocationType>;
export type Location = z.infer<typeof schemas.Location>;
export type SexualContentLevel = z.infer<typeof schemas.SexualContentLevel>;
export type ViolentContentLevel = z.infer<typeof schemas.ViolentContentLevel>;
export type ActionEvent = z.infer<typeof schemas.ActionEvent>;
export type NarrationEvent = z.infer<typeof schemas.NarrationEvent>;
export type CharacterIntroductionEvent = z.infer<typeof schemas.CharacterIntroductionEvent>;
export type LocationChangeEvent = z.infer<typeof schemas.LocationChangeEvent>;
export type Event = z.infer<typeof schemas.Event>;
export type Action = z.infer<typeof schemas.Action>;
export type EventHistoryEntry = z.infer<typeof schemas.EventHistoryEntry>;
export type EventHistory = z.infer<typeof schemas.EventHistory>;
export type State = z.infer<typeof schemas.State>;

export const initialState: State = schemas.State.parse({
  apiUrl: "http://localhost:9931/v1/",
  apiKey: "",
  model: "",
  contextLength: 16384,
  inputLength: 16384,
  generationParams: {
    temperature: 0.5,
  },
  narrationParams: {
    temperature: 1.0,
    top_p: 0.95,
  },
  updateInterval: 200,
  logPrompts: false,
  logParams: false,
  logResponses: false,
  view: "welcome",
  world: {
    name: "[name]",
    description: "[description]",
  },
  locations: [],
  characters: [],
  protagonist: {
    name: "[name]",
    gender: "male",
    race: "human",
    biography: "[biography]",
    locationIndex: 0,
  },
  hiddenDestiny: false,
  betrayal: false,
  oppositeSexMagnet: false,
  sameSexMagnet: false,
  sexualContentLevel: "regular",
  violentContentLevel: "regular",
  events: [],
  actions: [],
  eventHistory: {},
});

export type Plugin = Partial<{
  // The context is determined by the environment in which the plugin runs,
  // e.g. a frontend that provides methods for adding custom components.
  init(settings: Record<string, unknown>, context: unknown): Promise<void>;

  getBackends(): Promise<Record<string, Backend>>;

  onLocationChange(newLocation: Location, state: WritableDraft<State>): Promise<void>;
}>;

export interface PluginWrapper {
  name: string;
  enabled: boolean;
  settings: Record<string, unknown>;
  plugin: Plugin;
}

export interface Plugins {
  plugins: PluginWrapper[];
  backends: Record<string, Backend>;
  activeBackend: string;
}

export interface Actions {
  set: (
    nextStateOrUpdater: StoredState | Partial<StoredState> | ((state: WritableDraft<StoredState>) => void),
    shouldReplace?: false,
  ) => void;
  setAsync: (updater: (state: WritableDraft<StoredState>) => Promise<void>) => Promise<void>;
}

export type StoredState = State & Plugins & Actions;

const setAsyncMutex = new Mutex();

export const useStateStore = create<StoredState>()(
  persist(
    immer((set, get) => ({
      ...initialState,
      plugins: [],
      backends: {},
      activeBackend: "default",
      set: set,
      setAsync: async (updater) => {
        await setAsyncMutex.runExclusive(async () => {
          // According to https://immerjs.github.io/immer/async/, this is an "anti-pattern", because
          // "updates [...] that happen during the async process, would be "missed" by the draft".
          // However, for our use case, this is actually exactly what we want, because it prevents
          // manual updates during state machine operations from producing inconsistent states.
          const state = get();
          const draft = createDraft(state);

          try {
            await updater(draft);
          } catch (error) {
            // Roll back any changes the updater may have written to the state store.
            set(state);
            // Re-throw the error to be handled by higher-level logic.
            throw error;
          }

          const newState = finishDraft(draft);
          set(newState);
        });
      },
    })),
    {
      name: "state",
      version: 1,
      partialize: (state) => {
        // Don't persist functions and class instances.
        const persistedState: Partial<StoredState> = { ...state };

        persistedState.plugins = state.plugins.map((plugin) => {
          const persistedPlugin: Partial<PluginWrapper> = { ...plugin };
          delete persistedPlugin.plugin;
          return persistedPlugin as PluginWrapper;
        });

        delete persistedState.backends;
        delete persistedState.set;
        delete persistedState.setAsync;

        return persistedState;
      },
      migrate: (persistedState) => {
        const state = persistedState as Partial<StoredState> & { versionActions?: Record<string, Action[][]> };

        // Before state version 1, the action suggestions belonging to a
        // version of a narration event were stored in a separate record
        // keyed by event index (outer) and version index (inner). Embed
        // them into the corresponding event history entries instead.
        if (state.versionActions) {
          if (!state.eventHistory) {
            state.eventHistory = {};
          }
          for (const [key, actionsPerVersion] of Object.entries(state.versionActions)) {
            const eventIndex = Number.parseInt(key, 10);
            if (Number.isNaN(eventIndex)) {
              continue;
            }
            const history = state.eventHistory[key];
            if (history) {
              for (let versionIndex = 0; versionIndex < history.entries.length; versionIndex++) {
                history.entries[versionIndex].actions = actionsPerVersion[versionIndex] ?? [];
              }
            } else {
              const event = state.events?.[eventIndex];
              if (event) {
                state.eventHistory[key] = {
                  entries: [
                    {
                      event: { ...event },
                      timestamp: Date.now(),
                      type: event.type === "action" ? "edit" : "regenerate",
                      actions: actionsPerVersion[0] ?? [],
                    },
                  ],
                  currentVersionIndex: 0,
                };
              }
            }
          }
          delete state.versionActions;
        }

        return state as StoredState;
      },
    },
  ),
);

export function getState(): StoredState {
  return useStateStore.getState();
}

/**
 * Initialize history for an event if it doesn't exist
 */
export function ensureEventHistory(eventIndex: number): void {
  if (eventIndex < 0) {
    return;
  }
  getState().set((state) => {
    const key = String(eventIndex);
    if (!state.eventHistory) {
      state.eventHistory = {};
    }
    if (!state.eventHistory[key]) {
      const event = state.events[eventIndex];
      if (event) {
        state.eventHistory[key] = {
          entries: [
            {
              event: { ...event },
              timestamp: Date.now(),
              type: event.type === "action" ? "edit" : "regenerate",
            },
          ],
          currentVersionIndex: 0,
        };
      }
    }
  });
}

/**
 * Add a new version to an event's history
 */
export function addEventHistoryVersion(eventIndex: number, newEvent: Event, type: "edit" | "regenerate"): void {
  if (eventIndex < 0) {
    return;
  }
  getState().set((state) => {
    const key = String(eventIndex);
    if (!state.eventHistory) {
      state.eventHistory = {};
    }
    if (!state.eventHistory[key]) {
      // Initialize history with current event if it exists, otherwise with the new event
      const event = state.events[eventIndex];
      if (event) {
        state.eventHistory[key] = {
          entries: [
            {
              event: { ...event },
              timestamp: Date.now(),
              type: event.type === "action" ? "edit" : "regenerate",
            },
          ],
          currentVersionIndex: 0,
        };
      } else {
        // Event doesn't exist, create history with the new event as the first entry
        state.eventHistory[key] = {
          entries: [
            {
              event: { ...newEvent },
              timestamp: Date.now(),
              type,
            },
          ],
          currentVersionIndex: 0,
        };
        // Create the event in the events array
        state.events[eventIndex] = newEvent;
        return;
      }
    }
    const history = state.eventHistory[key];
    if (history) {
      history.entries.push({
        event: { ...newEvent },
        timestamp: Date.now(),
        type,
      });
      history.currentVersionIndex = history.entries.length - 1;
      // Update the actual event in the events array
      state.events[eventIndex] = newEvent;
    }
  });
}

/**
 * Remove and insert events in the events array while keeping the keys of
 * eventHistory (which are event indices) consistent with the new positions.
 *
 * Inserted events never have history entries of their own, and entries of
 * removed events are discarded.
 */
function spliceEventsWithHistoryReindex(
  state: WritableDraft<StoredState>,
  start: number,
  deleteCount: number,
  inserts: Event[],
): void {
  state.events.splice(start, deleteCount, ...inserts);

  if (state.eventHistory) {
    const newHistory: Record<string, EventHistory> = {};
    for (const [key, value] of Object.entries(state.eventHistory)) {
      const index = Number.parseInt(key, 10);
      if (Number.isNaN(index)) {
        continue;
      }
      if (index >= start && index < start + deleteCount) {
        // History of a removed event is discarded.
        continue;
      }
      const newIndex = index < start ? index : index - deleteCount + inserts.length;
      newHistory[String(newIndex)] = value;
    }
    state.eventHistory = newHistory;
  }
}

/**
 * Make the block of character introduction events that follows a narration
 * event match the narration's current version: characters referenced by this
 * version that have not been introduced by earlier narrations get an
 * introduction, all other introductions in the block are removed.
 *
 * This must be called whenever the current version of a narration event
 * changes (swipe, regenerate, variant deletion).
 */
export function syncCharacterIntroductions(state: WritableDraft<StoredState>, eventIndex: number): void {
  const event = state.events[eventIndex];
  if (!event || event.type !== "narration") {
    return;
  }

  // Find the extent of the introduction block following the narration.
  let blockEnd = eventIndex + 1;
  while (blockEnd < state.events.length && state.events[blockEnd].type === "character_introduction") {
    blockEnd++;
  }
  const introductionCount = blockEnd - (eventIndex + 1);

  // Characters introduced by earlier narrations must not be introduced again.
  const introducedEarlier = new Set<number>();
  for (let i = 0; i < eventIndex; i++) {
    const previousEvent = state.events[i];
    if (previousEvent.type === "character_introduction") {
      introducedEarlier.add(previousEvent.characterIndex);
    }
  }

  const introductions = event.referencedCharacterIndices
    .filter((characterIndex) => !introducedEarlier.has(characterIndex) && state.characters[characterIndex])
    .map((characterIndex) => ({
      type: "character_introduction" as const,
      characterIndex,
    }));

  if (introductionCount > 0 || introductions.length > 0) {
    spliceEventsWithHistoryReindex(state, eventIndex + 1, introductionCount, introductions);
  }
}

/**
 * Store the action suggestions that belong to the current version of a
 * narration event, so that they can be restored when the user switches
 * to that version. The suggestions are embedded directly in the version's
 * event history entry.
 *
 * This operates on a state draft, so it can be called from within
 * state machine operations that hold an immer draft (see setAsync).
 */
export function storeVersionActions(state: WritableDraft<StoredState>, eventIndex: number, actions: Action[]): void {
  const key = String(eventIndex);
  if (!state.eventHistory) {
    state.eventHistory = {};
  }
  if (!state.eventHistory[key]) {
    // The event has no history yet, so create one containing the current
    // event as its only version; the suggestions then belong to that version.
    const event = state.events[eventIndex];
    if (!event) {
      return;
    }
    state.eventHistory[key] = {
      entries: [
        {
          event: { ...event },
          timestamp: Date.now(),
          type: event.type === "action" ? "edit" : "regenerate",
        },
      ],
      currentVersionIndex: 0,
    };
  }
  const history = state.eventHistory[key];
  if (history) {
    const entry = history.entries[history.currentVersionIndex];
    if (entry) {
      entry.actions = [...actions];
    }
  }
}

/**
 * Restore the action suggestions belonging to the current version of a
 * narration event into the global actions. Called whenever the current
 * version changes (swipe, regenerate, variant deletion).
 *
 * If no suggestions are stored for the version, the global suggestions are
 * cleared, so that stale suggestions from another version are never shown.
 */
function loadVersionActionsIntoState(state: WritableDraft<StoredState>, eventIndex: number): void {
  const history = state.eventHistory?.[String(eventIndex)];
  const actions = history?.entries[history.currentVersionIndex]?.actions;
  state.actions = actions ? [...actions] : [];
}

/**
 * Swipe to the previous (-1) or next (+1) version of an event's history
 */
export function swipeEventVersion(eventIndex: number, direction: -1 | 1): void {
  if (eventIndex < 0) {
    return;
  }
  getState().set((state) => {
    const history = state.eventHistory?.[String(eventIndex)];
    if (!history) {
      return;
    }
    const newVersionIndex = history.currentVersionIndex + direction;
    if (newVersionIndex < 0 || newVersionIndex >= history.entries.length) {
      return;
    }
    history.currentVersionIndex = newVersionIndex;
    state.events[eventIndex] = history.entries[newVersionIndex].event;
    syncCharacterIntroductions(state, eventIndex);
    loadVersionActionsIntoState(state, eventIndex);
  });
}

/**
 * Delete the current version of an event. If other versions exist, the next
 * one (or the previous one if there is no next one) is selected instead.
 * If no other version exists, the event is deleted completely, together with
 * its counterpart in the action/narration pair it belongs to.
 */
export function deleteEventVersion(eventIndex: number): void {
  if (eventIndex < 0) {
    return;
  }
  getState().set((state) => {
    const history = state.eventHistory?.[String(eventIndex)];
    if (!history || history.entries.length <= 1) {
      deleteEventPair(state, eventIndex);
      return;
    }

    const versionIndex = history.currentVersionIndex;
    // The action suggestions stored for the deleted version are discarded
    // together with its history entry; versions after it shift down by one.
    history.entries.splice(versionIndex, 1);
    // Swap to the version that followed the deleted one,
    // or to the previous one if there is no next one.
    const newVersionIndex = Math.min(versionIndex, history.entries.length - 1);
    history.currentVersionIndex = newVersionIndex;
    state.events[eventIndex] = history.entries[newVersionIndex].event;
    syncCharacterIntroductions(state, eventIndex);
    loadVersionActionsIntoState(state, eventIndex);
  });
}

/**
 * Delete an event completely, including all of its versions.
 *
 * Action and narration events form pairs that must not be broken up: there
 * must never be two narration answers in a row, nor an action without a
 * narration answering it. Therefore, deleting an action also deletes the
 * narration answering it, and deleting a narration also deletes the action
 * it answers.
 */
function deleteEventPair(state: WritableDraft<StoredState>, eventIndex: number): void {
  const event = state.events[eventIndex];
  if (!event) {
    return;
  }

  let start = eventIndex;
  if (event.type === "narration") {
    // Find the action that this narration answers, if any.
    // Everything between that action and this narration is part of the same
    // LLM answer (e.g. an earlier narration followed by a location change).
    for (let i = eventIndex - 1; i >= 0; i--) {
      if (state.events[i].type === "action") {
        start = i;
        break;
      }
    }
  }

  spliceEventsWithHistoryReindex(state, start, state.events.length - start, []);

  // Restore the action suggestions belonging to the LLM answer that is now
  // the last one, so that the suggestions always match the visible narration.
  // If no suggestions are stored for that answer (or no narration is left at
  // all), the global suggestions are cleared instead of keeping the stale
  // ones from the deleted answer.
  const lastNarrationIndex = state.events.findLastIndex((event) => event.type === "narration");
  loadVersionActionsIntoState(state, lastNarrationIndex);
}
