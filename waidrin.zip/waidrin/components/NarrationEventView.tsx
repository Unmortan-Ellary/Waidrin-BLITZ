// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

import { Box, Flex, HoverCard, IconButton, Link, Text } from "@radix-ui/themes";
import { useCallback, useMemo } from "react";
import { MdChevronLeft, MdChevronRight, MdDelete, MdRefresh } from "react-icons/md";
import Markdown from "react-markdown";
import { useShallow } from "zustand/shallow";
import type { NarrationEvent } from "@/lib/state";
import { useStateStore } from "@/lib/state";
import CharacterView from "./CharacterView";
import type { DeleteVersionHandler, RegenerateNarrationHandler, SwipeVersionHandler } from "./EventView";

interface NarrationEventViewProps {
  event: NarrationEvent;
  eventIndex?: number;
  showControls?: boolean;
  deleteDisabled?: boolean;
  busy?: boolean;
  onRegenerate?: RegenerateNarrationHandler;
  onSwipe?: SwipeVersionHandler;
  onDeleteVersion?: DeleteVersionHandler;
}

export default function NarrationEventView({
  event,
  eventIndex,
  showControls = true,
  deleteDisabled = false,
  busy = false,
  onRegenerate,
  onSwipe,
  onDeleteVersion,
}: NarrationEventViewProps) {
  const { characters, eventHistory } = useStateStore(
    useShallow((state) => ({
      characters: state.characters,
      eventHistory: state.eventHistory,
    })),
  );

  const hasEventIndex = eventIndex !== undefined && eventIndex >= 0;

  const history = hasEventIndex ? eventHistory?.[String(eventIndex)] : undefined;
  const versionCount = history ? history.entries.length : 1;
  const currentVersion = history ? history.currentVersionIndex + 1 : 1;

  // Hack to highlight dialogue in text:
  //
  // 1. Surround quoted portions of text with asterisks, marking them as italics.
  // 2. Use a custom <em> component (see below) to render italics as dialogue
  //    if they start with quotation marks.
  //
  // It would be cleaner to use a dedicated semantic element instead (e.g. <span class="...">),
  // but that requires enabling HTML support in react-markdown, which is a security risk.
  const markdown = event.text.replaceAll(/".*?(?:"|$)/g, "*$&*");

  const NameView = useCallback(
    // biome-ignore lint/suspicious/noExplicitAny: The correct type is private in react-markdown.
    (props: any) => {
      const { children } = props;

      if (typeof children === "string") {
        const possessiveSuffix = /'s?$/;
        const name = children.replace(possessiveSuffix, "");

        for (const character of characters) {
          if (character.name === name || character.name.split(" ")[0] === name) {
            return (
              <HoverCard.Root>
                <HoverCard.Trigger>
                  <Link color="blue" href="#" onClick={(event) => event.preventDefault()}>
                    {children}
                  </Link>
                </HoverCard.Trigger>
                <HoverCard.Content maxWidth="40rem">
                  <Box p="2">
                    <CharacterView character={character} />
                  </Box>
                </HoverCard.Content>
              </HoverCard.Root>
            );
          }
        }
      }

      return <strong>{children}</strong>;
    },
    [characters],
  );

  const DialogueView = useCallback(
    // biome-ignore lint/suspicious/noExplicitAny: The correct type is private in react-markdown.
    (props: any) => {
      const { children } = props;

      const firstChild = Array.isArray(children) && children.length > 0 ? children[0] : children;

      if (typeof firstChild === "string" && firstChild.startsWith('"')) {
        return <Text color="amber">{children}</Text>;
      } else {
        return <em>{children}</em>;
      }
    },
    [],
  );

  const components = useMemo(
    () => ({
      strong: NameView,
      em: DialogueView,
    }),
    [NameView, DialogueView],
  );

  return (
    <Box className="text-(length:--font-size-5) [&_p]:mb-[0.7em]" width="100%" p="6">
      <Markdown components={components}>{markdown}</Markdown>
      {showControls && hasEventIndex && eventIndex !== undefined && (
        <Flex justify="end" align="center" gap="2" mt="2">
          <IconButton
            size="2"
            variant="ghost"
            color="gray"
            disabled={busy || currentVersion <= 1}
            onClick={() => onSwipe?.(eventIndex, -1)}
            title="Previous version"
          >
            <MdChevronLeft />
          </IconButton>
          <Text className="tabular-nums" size="2" color="gray">
            {currentVersion}/{versionCount}
          </Text>
          <IconButton
            size="2"
            variant="ghost"
            color="gray"
            disabled={busy || currentVersion >= versionCount}
            onClick={() => onSwipe?.(eventIndex, 1)}
            title="Next version"
          >
            <MdChevronRight />
          </IconButton>
          <IconButton
            size="2"
            variant="ghost"
            color="gray"
            disabled={busy}
            onClick={() => onRegenerate?.(eventIndex)}
            title="Regenerate"
          >
            <MdRefresh />
          </IconButton>
          <IconButton
            size="2"
            variant="ghost"
            color="red"
            disabled={busy || deleteDisabled}
            onClick={() => onDeleteVersion?.(eventIndex)}
            title="Delete"
          >
            <MdDelete />
          </IconButton>
        </Flex>
      )}
    </Box>
  );
}
