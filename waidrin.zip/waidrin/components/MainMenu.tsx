// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

import { DropdownMenu, IconButton, Text } from "@radix-ui/themes";
import { GiElfHelmet } from "react-icons/gi";
import { reset } from "@/lib/engine";

export default function MainMenu() {
  return (
    <DropdownMenu.Root>
      <DropdownMenu.Trigger>
        <IconButton className="fixed top-3 left-3" variant="ghost" color="gray">
          <GiElfHelmet size="35" />
        </IconButton>
      </DropdownMenu.Trigger>

      <DropdownMenu.Content color="gray">
        <DropdownMenu.Item color="red" onClick={reset}>
          <Text size="5">Reset state (wipes all progress)</Text>
        </DropdownMenu.Item>
      </DropdownMenu.Content>
    </DropdownMenu.Root>
  );
}
