// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

import { Flex, ScrollArea, Text } from "@radix-ui/themes";
import { useCallback, useEffect, useRef, useState } from "react";
import { useShallow } from "zustand/shallow";
import ActionChoice from "@/components/ActionChoice";
import ErrorBar from "@/components/ErrorBar";
import EventView from "@/components/EventView";
import ProcessingBar from "@/components/ProcessingBar";
import { abort, isAbortError, next, regenerateActions, regenerateNarration } from "@/lib/engine";
import { deleteEventVersion, swipeEventVersion, useStateStore } from "@/lib/state";

// If the user has scrolled further up than this distance (in pixels) from
// the bottom, new content must not move the scroll position.
const SCROLL_PIN_THRESHOLD = 100;

export default function Chat() {
  const [busy, setBusy] = useState(false);
  const [barTitle, setBarTitle] = useState("");
  const [barTokenCount, setBarTokenCount] = useState(0);
  const [errorMessage, setErrorMessage] = useState("");

  const busyRef = useRef(false);
  const retryRef = useRef<(() => void) | undefined>(undefined);

  const { events, actions, eventHistory } = useStateStore(
    useShallow((state) => ({
      events: state.events,
      actions: state.actions,
      eventHistory: state.eventHistory,
    })),
  );

  const lastNarrationIndex = events.findLastIndex((event) => event.type === "narration");
  const firstNarrationIndex = events.findIndex((event) => event.type === "narration");
  const lastNarrationVersionCount = eventHistory?.[String(lastNarrationIndex)]?.entries.length ?? 1;

  // Deleting the very first LLM answer entirely would break the game, so its
  // Delete button is disabled while it is the only version; deleting single
  // versions of it (and any version of any other answer) remains possible.
  const lastNarrationDeleteDisabled = lastNarrationIndex === firstNarrationIndex && lastNarrationVersionCount <= 1;

  const eventsContainerRef = useRef<HTMLDivElement | null>(null);

  // Whether the user is currently at (or near) the bottom of the events
  // container. New content is only scrolled into view if this is the case.
  const pinnedToBottomRef = useRef(true);

  // Set when the user switches between message versions, so that the
  // resulting content change does not move the scroll position.
  const suppressAutoScrollRef = useRef(false);

  const execute = useCallback(
    async (
      run: (onProgress: (title: string, message: string, tokenCount: number) => void) => Promise<void>,
      retry: () => void,
    ) => {
      if (busyRef.current) {
        return;
      }
      busyRef.current = true;
      setBusy(true);
      setErrorMessage("");
      setBarTokenCount(0);
      try {
        await run((title, _message, tokenCount) => {
          setBarTitle(title);
          setBarTokenCount(tokenCount);
        });
      } catch (error) {
        if (!isAbortError(error)) {
          let message = error instanceof Error ? error.message : String(error);
          if (!message) {
            message = "Unknown error";
          }
          setErrorMessage(message);
          // Allow retrying the failed operation via the error bar.
          retryRef.current = retry;
          return;
        }
      } finally {
        busyRef.current = false;
        setBusy(false);
      }
    },
    [],
  );

  const doAction = useCallback(
    (action?: string) => {
      return execute(
        (onProgress) => next(action, onProgress),
        () => doAction(action),
      );
    },
    [execute],
  );

  const handleRegenerateNarration = useCallback(
    (eventIndex: number) => {
      return execute(
        (onProgress) => regenerateNarration(eventIndex, onProgress),
        () => handleRegenerateNarration(eventIndex),
      );
    },
    [execute],
  );

  const handleRegenerateActions = useCallback(() => {
    return execute(
      (onProgress) => regenerateActions(onProgress),
      () => handleRegenerateActions(),
    );
  }, [execute]);

  const handleSwipeVersion = useCallback((eventIndex: number, direction: -1 | 1) => {
    suppressAutoScrollRef.current = true;
    swipeEventVersion(eventIndex, direction);
  }, []);

  const handleDeleteVersion = useCallback((eventIndex: number) => {
    suppressAutoScrollRef.current = true;
    deleteEventVersion(eventIndex);
  }, []);

  // Track whether the user is at the bottom of the events container.
  //
  // The pin state is only updated in response to user-initiated scrolling
  // (mouse wheel, touch, keyboard, or scrollbar drag). Scroll events caused
  // by automatic scrolling, or by the browser clamping scrollTop after
  // content above the position was removed, must not change the pin state,
  // otherwise the view would snap to the bottom and follow the stream
  // against the user's intention.
  useEffect(() => {
    const eventsContainer = eventsContainerRef.current;
    if (!eventsContainer) {
      return;
    }

    let draggingScrollbar = false;
    let lastUserInputTime = 0;

    const markUserInput = () => {
      lastUserInputTime = performance.now();
    };

    const isUserScroll = () => draggingScrollbar || performance.now() - lastUserInputTime < 200;

    const onScroll = () => {
      if (!isUserScroll()) {
        return;
      }
      const distanceFromBottom =
        eventsContainer.scrollHeight - eventsContainer.scrollTop - eventsContainer.clientHeight;
      pinnedToBottomRef.current = distanceFromBottom < SCROLL_PIN_THRESHOLD;
    };

    eventsContainer.addEventListener("scroll", onScroll, { passive: true });
    eventsContainer.addEventListener("wheel", markUserInput, { passive: true });
    eventsContainer.addEventListener("touchmove", markUserInput, { passive: true });
    eventsContainer.addEventListener("keydown", markUserInput);

    // Scrolling by dragging the scrollbar thumb must also count as user
    // input. The thumb is a sibling of the viewport, so its pointer events
    // do not reach the viewport itself.
    const scrollAreaRoot = eventsContainer.closest(".rt-ScrollAreaRoot");
    const onPointerDown = () => {
      draggingScrollbar = true;
    };
    const onPointerUp = () => {
      draggingScrollbar = false;
    };
    scrollAreaRoot?.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointerup", onPointerUp);

    return () => {
      eventsContainer.removeEventListener("scroll", onScroll);
      eventsContainer.removeEventListener("wheel", markUserInput);
      eventsContainer.removeEventListener("touchmove", markUserInput);
      eventsContainer.removeEventListener("keydown", markUserInput);
      scrollAreaRoot?.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointerup", onPointerUp);
    };
  }, []);

  // Scroll to the bottom of the events container when new content is added,
  // but only if the user is at the bottom and has not just switched between
  // message versions.
  //
  // biome-ignore lint/correctness/useExhaustiveDependencies: The dependency is indirect.
  useEffect(() => {
    if (suppressAutoScrollRef.current) {
      suppressAutoScrollRef.current = false;
      return;
    }

    const eventsContainer = eventsContainerRef.current;
    if (eventsContainer && pinnedToBottomRef.current) {
      eventsContainer.scroll({
        top: eventsContainer.scrollHeight,
        behavior: "smooth",
      });
    }
  }, [events]);

  // Forward the state machine once after transitioning to the chat view
  // to generate initial narration and actions.
  //
  // biome-ignore lint/correctness/useExhaustiveDependencies: This should run only once.
  useEffect(() => {
    if (actions.length === 0) {
      doAction();

      // Note that in Strict Mode (used during development), React runs the effect twice
      // *even with an empty dependency array*, so the cleanup function is important here
      // (see https://react.dev/learn/synchronizing-with-effects#how-to-handle-the-effect-firing-twice-in-development).
      return () => abort();
    }
  }, []);

  return (
    <Flex width="100%" justify="center">
      <Flex
        className="bg-black border-l border-r border-(--gold-10) shadow-[0_0_30px_var(--slate-10)]"
        direction="column"
        width="60rem"
        height="100vh"
      >
        <ScrollArea ref={eventsContainerRef}>
          <Flex direction="column">
            {events.map((event, index) => (
              <EventView
                // biome-ignore lint/suspicious/noArrayIndexKey: Events are append-only, so this is valid.
                key={index}
                event={event}
                eventIndex={index}
                showControls={index === lastNarrationIndex}
                deleteDisabled={index === lastNarrationIndex && lastNarrationDeleteDisabled}
                busy={busy}
                onRegenerate={handleRegenerateNarration}
                onSwipe={handleSwipeVersion}
                onDeleteVersion={handleDeleteVersion}
              />
            ))}
          </Flex>
        </ScrollArea>

        {actions.length > 0 && !errorMessage && (
          <ActionChoice busy={busy} onRegenerate={handleRegenerateActions} onAction={(action) => doAction(action)} />
        )}

        {busy && (
          <ProcessingBar title={barTitle} onCancel={abort}>
            <Text className="tabular-nums" as="div" align="right" size="4" color="lime" mr="2">
              {barTokenCount ? `Tokens generated: ${barTokenCount}` : "Waiting for response..."}
            </Text>
          </ProcessingBar>
        )}

        {errorMessage && (
          <ErrorBar
            errorMessage={errorMessage}
            onRetry={() => {
              setErrorMessage("");
              const retry = retryRef.current;
              retryRef.current = undefined;
              retry?.();
            }}
            onCancel={() => {
              retryRef.current = undefined;
              setErrorMessage("");
            }}
          />
        )}
      </Flex>
    </Flex>
  );
}
