// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

// Central place for resolving image URLs. The Next.js build serves images
// from the /images directory; the standalone single-file build replaces this
// module with one that returns embedded base64 data URLs.
export function imageSrc(name: string): string {
  return `/images/${name}.png`;
}
