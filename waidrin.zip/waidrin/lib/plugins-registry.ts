// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

import type { Manifest } from "@/app/plugins/route";
import type { Plugin } from "./state";

export type PluginModule = { default: new () => Plugin };

// Central place for loading plugins. The Next.js build fetches plugin
// manifests and modules from the /plugins endpoints; the standalone
// single-file build replaces this module with one that uses embedded data.
export async function fetchPluginManifests(): Promise<Manifest[]> {
  const response = await fetch("/plugins");
  return await response.json();
}

export async function importPluginModule(manifest: Manifest): Promise<PluginModule> {
  return await import(/* webpackIgnore: true */ `/plugins/${manifest.path}/${manifest.main}`);
}
