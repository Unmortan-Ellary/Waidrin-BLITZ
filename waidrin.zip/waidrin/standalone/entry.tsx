// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

// Entry point for the standalone single-file build. Reproduces the structure
// of the Next.js app/layout.tsx (dark theme, plum accent) without the
// Next.js runtime.
import { Theme } from "@radix-ui/themes";
import { createRoot } from "react-dom/client";
import Home from "@/app/page";

const rootElement = document.getElementById("root");
if (rootElement) {
  createRoot(rootElement).render(
    <Theme appearance="dark" accentColor="plum">
      <Home />
    </Theme>,
  );
}
