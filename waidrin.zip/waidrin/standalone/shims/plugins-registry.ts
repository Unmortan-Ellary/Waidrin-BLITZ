// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

// Replacement for lib/plugins-registry in the standalone single-file build.
// Instead of fetching plugin manifests and modules from the /plugins
// endpoints, the demo plugin is embedded directly.
import type { Manifest } from "@/app/plugins/route";
import type { PluginModule } from "@/lib/plugins-registry";
import type { Plugin } from "@/lib/state";
import DemoPlugin from "../../plugins/demo-plugin/main.js";

const manifests: Manifest[] = [
  {
    path: "demo-plugin",
    name: "Demo Plugin",
    main: "main.js",
    settings: { loggingEnabled: true },
  },
];

export async function fetchPluginManifests(): Promise<Manifest[]> {
  return manifests;
}

export async function importPluginModule(manifest: Manifest): Promise<PluginModule> {
  if (manifest.name === "Demo Plugin") {
    return { default: DemoPlugin as unknown as new () => Plugin };
  }
  throw new Error(`Plugin "${manifest.name}" is not available in the standalone build`);
}
