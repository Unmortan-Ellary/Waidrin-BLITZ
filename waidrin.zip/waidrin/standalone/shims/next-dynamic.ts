// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2025  Philipp Emanuel Weidmann <pew@worldwidemann.com>

// Replacement for next/dynamic in the standalone single-file build.
// Loads the component lazily via React.lazy instead of the Next.js
// dynamic import mechanism.
import * as React from "react";

// biome-ignore lint/suspicious/noExplicitAny: Matches the loose typing of next/dynamic.
export default function dynamic(loader: () => Promise<any>, _options?: { ssr?: boolean }) {
  const LazyComponent = React.lazy(loader);

  // biome-ignore lint/suspicious/noExplicitAny: Matches the loose typing of next/dynamic.
  return function DynamicComponent(props: any) {
    return React.createElement(React.Suspense, { fallback: null }, React.createElement(LazyComponent, props));
  };
}
